import axios from 'axios';
const api = axios.create({
 baseURL: 'http://localhost:3001'
});
export const getBook = () => api.get('/livros');
export const getBookById = (id: string) => api.get(`/livros/${id}`);
export const createBook = (book: any) => api.post('/livros', book);
export const updateBook = (id: string, book: any) => api.put(`/livros/${id}`, book);
export const deleteBook = (id: string) => api.delete(`/livros/${id}`);