import { useEffect, useState } from 'react';
import { getBook, deleteBook } from '../services/api';
import { Link } from 'react-router-dom';
interface Livro {
 id: string;
 titulo: string;
 autor: string;
 ano: number;
 genero: string;
 pgqtd: number;
}
function BookList() {
 const [books, setBooks] = useState<Livro[]>([]);
 useEffect(() => {
 loadBooks();
 }, []);
 const loadBooks = async () => {
 const response = await getBook();
 setBooks(response.data);
 };
 const handleDelete = async (id: string) => {
 await deleteBook(id);
 loadBooks();
 };
 return (
 <div>
 <h1>Lista de livros</h1>
 <Link to="/add">Add Product</Link>
 <ul>
 {books.map((books) => (
 <li key={books.id}>
 {books.titulo} - {books.autor} - {books.ano} - {books.genero} - {books.pgqtd} paginas
 <Link to={`/edit/${books.id}`}>Edit</Link>
 <button onClick={() => handleDelete(books.id)}>Delete</button>
 </li>
 ))}
 </ul>
 </div>
 );
}
export default BookList;