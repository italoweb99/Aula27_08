import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createBook, getBookById, updateBook } from '../services/api';
interface Livro {
    titulo: string;
    autor: string;
    ano: number;
    genero: string;
    pgqtd: number;
   }
function BookForm() {
 const { id } = useParams<{ id: string }>();
 const navigate = useNavigate();
 const [books, setBook] = useState<Livro>({
 titulo: '',
 autor: '',
 ano: 0,
 genero: '',
 pgqtd: 0,
 });
 useEffect(() => {
 if (id) {
 loadBook();
 }
 }, [id]);
 const loadBook = async () => {
 try {
 const response = await getBookById(id as string);
 setBook(response.data);
 } catch (error) {
 console.error("Error loading product data", error);
 }
 };
 const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
 setBook({
 ...books,
 [e.target.name]: e.target.value,
 });
 };
 const handleSubmit = async (e: React.FormEvent) => {
 e.preventDefault();
 try {
 if (id) {
 await updateBook(id, books);
 } else {
 await createBook(books);
 }
 navigate('/');
 } catch (error) {
 console.error("Error saving product", error);
 }
 };
 return (
 <form onSubmit={handleSubmit}>
 <div>
 <label>Titulo</label>
 <input
 type="text"
 name="titulo"
 value={books.titulo}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Autor</label>
 <input
 type="text"
 name="autor"
 value={books.autor}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Ano</label>
 <input
 type="number"
 name="ano"
 value={books.ano}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Genero</label>
 <input
 type="text"
 name="genero"
 value={books.genero}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Quantidade de paginas</label>
 <input
 type="number"
 name="pgqtd"
 value={books.pgqtd}
 onChange={handleChange}
 />
 </div>
 <button type="submit">Save</button>
 </form>
 );
}
export default BookForm;