import LivroForm from '../components/LivroForm';
function AddProduct() {
 return (
 <div>
 <h1>Adicionar livro</h1>
 <LivroForm />
 </div>
 );
}
export default AddProduct;