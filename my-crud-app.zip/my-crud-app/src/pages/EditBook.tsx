import LivroForm from '../components/LivroForm';
function EditBook() {
 return (
 <div>
 <h1>Edite livro</h1>
 <LivroForm />
 </div>
 );
}
export default EditBook;